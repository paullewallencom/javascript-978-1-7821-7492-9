TestCase("Very simple Tests", function(){
	testA: function(){
	}
	testB: function(){
	}
});
