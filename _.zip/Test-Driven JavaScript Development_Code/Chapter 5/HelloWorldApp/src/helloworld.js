myapp = {};

myapp.HelloWorldApp = function() { };

myapp.HelloWorldApp.prototype.say = function(name) {
  return "Hello " + name + "!";
};

function add(a, b){
	return a + b;
}
