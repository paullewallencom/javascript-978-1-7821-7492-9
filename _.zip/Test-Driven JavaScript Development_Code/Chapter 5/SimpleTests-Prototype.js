SimpleTest = TestCase("Very simple Tests");

SimpleTest.prototype.testA = function(){
};

SimpleTest.prototype.testB = function(){
};