/*
This file contains our logical code, functions, etc.
*/

// function to add two values.
function add(a, b){
	return a + b;
}
