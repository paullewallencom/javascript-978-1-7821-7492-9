describe("Testing Company wide functions", function(){
	describe("Testing HR department functions", function(){
		
		describe("Testing HR department functions - Prize Distribution", function(){
			
		});
		describe("Testing HR department functions - Offer Letter Distribution", function(){
			
		});
		describe("Testing HR department functions - New recruitment", function(){
			
		});
	});
	describe("Testing Admin department functions", function(){
		
		describe("Testing Admin department functions - Reception", function(){
			
		});
		describe("Testing Admin department functions - Pantry", function(){
			
		});
	});	
	describe("Testing Finance department functions", function(){
		
		describe("Testing Finance department functions - Reimbursement", function(){
			
		});
		describe("Testing Finance department functions - Salary", function(){
			
		});
	});	
	
});

