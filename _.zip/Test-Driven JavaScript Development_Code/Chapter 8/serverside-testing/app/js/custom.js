$.validate({
  form : '#add_ticket, #login'
});
